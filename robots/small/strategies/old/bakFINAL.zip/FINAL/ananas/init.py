
State.pokupio = 0
def run():
	r.conf_set('send_status_interval', 10)

	r.setpos(0,0,0)#r.setpos(-1425,-575,180) # red
	r.speed(80)
	
