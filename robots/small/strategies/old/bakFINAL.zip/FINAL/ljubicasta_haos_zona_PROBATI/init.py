def run():
	r.conf_set('send_status_interval', 10)

	r.setpos(-1195,-610,90) 

	r.speed(50)
	nazgold(0)
	napgold(0)
	lfliper(0)
	rfliper(0)
	rrucica(0)
	lrucica(0)
